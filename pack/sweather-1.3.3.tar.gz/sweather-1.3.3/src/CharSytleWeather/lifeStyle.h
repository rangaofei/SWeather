//
// Created by 冉高飞 on 2018/7/27.
//

#ifndef SWEATHER_LIFESTYLE_H
#define SWEATHER_LIFESTYLE_H

#include "CJson/cJSON.h"

typedef struct lifestyle_forecast {
    char *brf;
    char *txt;
    char *type;
} LifestyleForecast;

void printLifeStyle(int i);

void processLifeStyle(cJSON *lifeStyle);

#endif //SWEATHER_LIFESTYLE_H
