//
// Created by 冉高飞 on 2018/7/26.
//

#ifndef SWEATHER_PRINTERUTIL_H
#define SWEATHER_PRINTERUTIL_H

// 清除屏幕
#define CLEAR() printf("\033[2J")

// 上移光标
#define MOVEUP(x) printf("\033[%dA", (x));

#define MOVEUP_NOT_PRINT "\033[%10A"

// 下移光标
#define MOVEDOWN(x) printf("\033[%dB", (x));

#define MOVEDOWN_NOT_PRINT "\033[%1B"

// 左移光标
#define MOVELEFT(y) printf("\033[%dD", (y));

#define MOVELEFT_NOT_PRINT "\033[%100D"

// 右移光标
#define MOVERIGHT(y) printf("\033[%dC",(y));

#define MOVERIGHT_NOT_PRINT "\033[%2C"

// 定位光标
#define MOVETO(x, y) printf("\033[%d;%dH", (x), (y))

#define MOVETO_NOT_RPINT "\033[%-10;%1H"

// 光标复位
#define RESET_CURSOR() printf("\033[H")

#define RESET_CURSOR_NOT_PRINT "\033[H"

// 隐藏光标
#define HIDE_CURSOR() printf("\033[?25l")

//保存光标位置
#define SAVE_CURSOR "\033[s"

//回复光标位置
#define RESTORE_CURSOR printf("\033[u");

void printFourRect();

#endif //SWEATHER_PRINTERUTIL_H
