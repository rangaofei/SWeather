//
// Created by 冉高飞 on 2018/7/25.
//

#include <string.h>
#include "dailyForecast.h"
#include "printerUtil.h"
#include "strcut_info.h"

/**
 * 天气晴
 */
#define SUNNY_PRINT(x)  MOVERIGHT(x) printf(SHINING_RED"      \\   /       "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_RED"       .-.        "NONE);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(x) printf(SHINING_RED"    -"NONE LIGHT_RED" ( o ) "NONE SHINING_RED"-     "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_RED"       `-’        "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(SHINING_RED"      /   \\       "NONE"");MOVEDOWN(1) MOVELEFT(200)

/**
 * 天气多云
 */

#define CLOUDY_PRINT(x) MOVERIGHT(x) printf(LIGHT_CYAN"                  "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_CYAN"         .-.      "NONE);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_CYAN"        (_ "LIGHT_GRAY"."LIGHT_CYAN" )    "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_CYAN"     .(  "LIGHT_GRAY"(___)    "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_CYAN"    (___"LIGHT_GRAY"(______)  "NONE);MOVEDOWN(1) MOVELEFT(200)

/**
 * 天气阴
 */
#define SUNNY_CLOUDY_PRINT(x) MOVERIGHT(x)printf(SHINING_RED"      \\   /       "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_RED"       .-.        "NONE);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(x) printf(SHINING_RED"    - "NONE LIGHT_RED"(   "CYAN".-.     "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_RED"        "CYAN"( _ ).   "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(SHINING_RED"      / "NONE CYAN"(___(__)  "NONE);MOVEDOWN(1) MOVELEFT(200)

/**
 * 天气雷阵雨
 */
#define THUNDER_RAIN_PRINT(x) MOVERIGHT(x)printf(LIGHT_CYAN"     .-.         "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_CYAN"    (   ).       "NONE);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_CYAN"   (___(__)      "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_GRAY"   "SHINING_YELLOW"⚡"LIGHT_GRAY"''"SHINING_YELLOW"⚡"LIGHT_GRAY"''       "NONE);MOVEDOWN(1) MOVELEFT(200)\
MOVERIGHT(x) printf(LIGHT_GRAY"    ' ' ' '      "NONE);MOVEDOWN(1) MOVELEFT(200)
char *thunder_rain_only = LIGHT_CYAN"    .-.         "MOVEDOWN_NOT_PRINT MOVELEFT_NOT_PRINT
                          MOVERIGHT_NOT_PRINT LIGHT_CYAN"   (   ).       "MOVEDOWN_NOT_PRINT MOVELEFT_NOT_PRINT
                          LIGHT_CYAN"   (___(__)      "NONE"\n"
                          LIGHT_GRAY"   "SHINING_YELLOW"⚡"LIGHT_GRAY"''"SHINING_YELLOW"⚡"LIGHT_GRAY"''       "NONE"\n"
                          LIGHT_GRAY"    ' ' ' '      "NONE"\n";

char *windy_only = LIGHT_RED"      \\   /      "NONE"\n"
                   LIGHT_RED"       .-.        "NONE"\n"
                   LIGHT_RED"    - (   ) -     "NONE"\n"
                   LIGHT_RED"       `-’        "NONE"\n"
                   LIGHT_RED"      /   \\      "NONE"\n";
/**
 * 天气小雨
 */
char *little_rain_only = LIGHT_CYAN"      .-.         "NONE"\n"
                         LIGHT_CYAN"     (   ).       "NONE"\n"
                         LIGHT_CYAN"    (___(__)      "NONE"\n"
                         LIGHT_GRAY"    ' ' ' '       "NONE"\n"
                         LIGHT_GRAY"     ' ' ' '      "NONE"\n";
/**
 * 天气大雨
 */
char *big_rain_only = LIGHT_CYAN"      .-.         "NONE"\n"
                      LIGHT_CYAN"     (   ).       "NONE"\n"
                      LIGHT_CYAN"    (___(__)      "NONE"\n"
                      DAR_GRAY  "    ‚‘‚‘‚‘‚‘      "NONE"\n"
                      DAR_GRAY  "    ‚‘‚‘‚‘‚‘      "NONE"\n";

char *patch_only = LIGHT_RED"      \\   /      "NONE"\n"
                   LIGHT_RED"       .-.        "NONE"\n"
                   LIGHT_RED"    - (   ) -     "NONE"\n"
                   LIGHT_RED"       `-’        "NONE"\n"
                   LIGHT_RED"      /   \\      "NONE"\n";
//东风，东南风，南风，西南风，西风，东北风，北风，西北风
char *wind_dir_icon_only[9] = {"→", "↘", "↓", "↙", "←", "↗", "↑", "↖", "O"};
char *wind_dir_txt_only[9] = {"东风", "东南风", "南风", "西南风", "西风", "东北风", "北风", "西北风", "无持续风向"};


#define PRINT_WEATHER(p, x1, xn, x2, x3, x4, x5, x6, x7, x8) MOVERIGHT(p)printf("天气：%s | %s",x1,xn);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(p)printf("温度：%s °C - %s °C",x2,x3);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(p)printf("风速：%s %s km/h",x4,x5);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(p)printf("见度：%s km",x6);MOVEDOWN(1)MOVELEFT(200)\
MOVERIGHT(p)printf("降雨：%s mm | %s%%",x7,x8);MOVEDOWN(2)MOVELEFT(200)RESTORE_CURSOR


void printForecastFormat(char *wind_dir, DailyForecast *dailyForecast, int padding) {
    if (padding > 1) {
        MOVERIGHT(2 + 9 + 31 * padding);
    } else {
        MOVERIGHT(2 + 10 + 31 * padding)
    }
    fprintf(stdout, "%s", dailyForecast->date);
    MOVEDOWN(2)
    MOVELEFT(200)
    switch (strtol(dailyForecast->cond_code_d, NULL, 0)) {
        case 100:
        SUNNY_PRINT(2 + 31 * padding)
            break;
        case 101:
        case 102:
        CLOUDY_PRINT(2 + 31 * padding)
            break;
        case 103:
        case 104:
        SUNNY_CLOUDY_PRINT(2 + 31 * padding)
            break;
        case 302:
        THUNDER_RAIN_PRINT(2 + 31 * padding)
            break;
        case 305:
//            break;
        case 307:
//            break;
        default:
        SUNNY_PRINT(2 + 31 * padding)
            break;
    }
    fprintf(stdout, "%s", "\n");
    PRINT_WEATHER(2 + 31 * padding,
                  dailyForecast->cond_txt_d, dailyForecast->cond_txt_n,
                  dailyForecast->tmp_max, dailyForecast->tmp_min,
                  wind_dir, dailyForecast->wind_spd,
                  dailyForecast->vis,
                  dailyForecast->pcpn, dailyForecast->hum);
}

void printForecast(DailyForecast *dailyForecast, int padding) {
    char *dir = NULL;
    for (int i = 0; i < 9; i++) {
        if (strcmp(dailyForecast->wind_dir, wind_dir_txt_only[i]) == 0) {
            dir = wind_dir_icon_only[i];
            break;
        }
    }
    printForecastFormat(dir, dailyForecast, padding);
}

void locationPrint() {
    //打印标题
    MOVEUP(15)
    MOVERIGHT(57)
    fprintf(stdout, "未来三天天气");
    MOVELEFT(100)
    MOVEDOWN(15)
    for (int i = 0; i < 4; i++) {
        MOVEUP(14);
        printForecast(&context.dailyForecast[i], i);
    }
}

/**
 * 显示最近四天天气
 * @param dailyForecast
 */

void processDailyForecast(cJSON *dailyForecast) {
    printFourRect();
    int length = cJSON_GetArraySize(dailyForecast);
    cJSON *item;
    for (int i = 0; i < length; ++i) {
        item = cJSON_GetArrayItem(dailyForecast, i);
        context.dailyForecast[i].date = cJSON_GetObjectItem(item, "date")->valuestring;
        context.dailyForecast[i].cond_code_d = cJSON_GetObjectItem(item, "cond_code_d")->valuestring;
        context.dailyForecast[i].cond_code_n = cJSON_GetObjectItem(item, "cond_code_n")->valuestring;
        context.dailyForecast[i].cond_txt_d = cJSON_GetObjectItem(item, "cond_txt_d")->valuestring;
        context.dailyForecast[i].cond_txt_n = cJSON_GetObjectItem(item, "cond_txt_n")->valuestring;
        context.dailyForecast[i].tmp_max = cJSON_GetObjectItem(item, "tmp_max")->valuestring;
        context.dailyForecast[i].tmp_min = cJSON_GetObjectItem(item, "tmp_min")->valuestring;
        context.dailyForecast[i].sr = cJSON_GetObjectItem(item, "sr")->valuestring;
        context.dailyForecast[i].ss = cJSON_GetObjectItem(item, "ss")->valuestring;
        context.dailyForecast[i].mr = cJSON_GetObjectItem(item, "mr")->valuestring;
        context.dailyForecast[i].ms = cJSON_GetObjectItem(item, "ms")->valuestring;
        context.dailyForecast[i].wind_dir = cJSON_GetObjectItem(item, "wind_dir")->valuestring;
        context.dailyForecast[i].wind_sc = cJSON_GetObjectItem(item, "wind_sc")->valuestring;
        context.dailyForecast[i].wind_spd = cJSON_GetObjectItem(item, "wind_spd")->valuestring;
        context.dailyForecast[i].wind_deg = cJSON_GetObjectItem(item, "wind_deg")->valuestring;
        context.dailyForecast[i].uv_index = cJSON_GetObjectItem(item, "uv_index")->valuestring;
        context.dailyForecast[i].vis = cJSON_GetObjectItem(item, "vis")->valuestring;
        context.dailyForecast[i].hum = cJSON_GetObjectItem(item, "hum")->valuestring;
        context.dailyForecast[i].pcpn = cJSON_GetObjectItem(item, "pcpn")->valuestring;
        context.dailyForecast[i].pop = cJSON_GetObjectItem(item, "pop")->valuestring;
        context.dailyForecast[i].pres = cJSON_GetObjectItem(item, "pres")->valuestring;
    }
    locationPrint();
}