/**
 * 绘制边框
 * 1.标题栏总宽度是35，可写区域33,偏移45
 * 2.边框总宽度是125
 * 3.每个格子可写宽度是30
 */
#include "printerUtil.h"
#include <stdio.h>

void printHorizontalLine(int limit) {
    for (int i = 0; i < limit; i++) {
        fprintf(stdout, "─");
    }
}

void printHeaderTop() {
    MOVERIGHT(54);
    fprintf(stdout, "┌");
    printHorizontalLine(16);
    fprintf(stdout, "┐");
}

void printHeaderMid() {
    fprintf(stdout, "┤");
    MOVERIGHT(16);
    fprintf(stdout, "├");
}

void printHeaderBottom() {
    fprintf(stdout, "└");
    printHorizontalLine(7);
    fprintf(stdout, "┬");
    printHorizontalLine(8);
    fprintf(stdout, "┘");
}

void printLineOne(int limit) {
    fprintf(stdout, "┌");
    printHorizontalLine(limit);
    fprintf(stdout, "┬");
    printHorizontalLine(22);
    printHeaderMid();
    printHorizontalLine(21);
    fprintf(stdout, "┬");
    printHorizontalLine(limit);
    fprintf(stdout, "┐");
}


void printLineTwo(int limit) {
    fprintf(stdout, "│");
    MOVERIGHT(limit);
    fprintf(stdout, "│");
    MOVERIGHT(22);
    printHeaderBottom();
    MOVERIGHT(21);
    fprintf(stdout, "│");
    MOVERIGHT(limit);
    fprintf(stdout, "│");
}

void printLineThree(int limit) {
    fprintf(stdout, "├");
    printHorizontalLine(limit);
    fprintf(stdout, "┼");
    printHorizontalLine(limit);
    fprintf(stdout, "┼");
    printHorizontalLine(limit);
    fprintf(stdout, "┼");
    printHorizontalLine(limit);
    fprintf(stdout, "┤");
}

void printLineSpace(int limit) {
    fprintf(stdout, "│");
    MOVERIGHT(limit);
    fprintf(stdout, "│");
    MOVERIGHT(limit);
    fprintf(stdout, "│");
    MOVERIGHT(limit);
    fprintf(stdout, "│");
    MOVERIGHT(limit);
    fprintf(stdout, "│");
}

void printLineLast(int limit) {
    fprintf(stdout, "└");
    printHorizontalLine(limit);
    fprintf(stdout, "┴");
    printHorizontalLine(limit);
    fprintf(stdout, "┴");
    printHorizontalLine(limit);
    fprintf(stdout, "┴");
    printHorizontalLine(limit);
    fprintf(stdout, "┘");
}

void printFourRect() {
    printHeaderTop();
    fprintf(stdout, "\n");
    printLineOne(30);
    fprintf(stdout, "\n");
    printLineTwo(30);
    fprintf(stdout, "\n");
    printLineThree(30);
    fprintf(stdout, "\n");
    for (int i = 0; i < 11; ++i) {
        printLineSpace(30);
        fprintf(stdout, "\n");
    }
    printLineLast(30);
    fprintf(stdout, "\n");
}