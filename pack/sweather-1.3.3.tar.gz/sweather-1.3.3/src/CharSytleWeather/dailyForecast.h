//
// Created by 冉高飞 on 2018/7/25.
//

#ifndef SWEATHER_DAILYFORECAST_H
#define SWEATHER_DAILYFORECAST_H

#include "CJson/cJSON.h"

#define NONE                    "\033[m"
#define RED                     "\033[0;32;31m"
#define LIGHT_RED               "\033[1;31m"
#define SHINING_RED             "\033[5;31m"
#define GREEN                   "\033[0;32;32m"
#define LIGHT_GREEN             "\033[1;32m"
#define BLUE                    "\033[0;32;34m"
#define LIGHT_BLUE              "\033[1;34m"
#define DAR_GRAY                "\033[1;30m"
#define CYAN                    "\033[0;36m"
#define LIGHT_CYAN              "\033[1;36m"
#define PURPLE                  "\033[0;35m"
#define LIGHT_PURPLE            "\033[1;35m"
#define BROWN                   "\033[0;33m"
#define YELLOW                  "\033[0;33m"
#define SHINING_YELLOW          "\033[5;33m"
#define LIGHT_GRAY              "\033[0;37m"
#define WHITE                   "\033[1;37m"
#define TASTE_RED               "\033[0;35m"

typedef struct daily_forecast {
    char *date;//预报日期
    char *sr;//日出事假
    char *ss;//日落时间
    char *mr;//月升时间
    char *ms;//月落时间
    char *tmp_max;//最高温度
    char *tmp_min;//最低温度
    char *cond_code_d;//白天天气代码
    char *cond_code_n;//晚间天气代码
    char *cond_txt_d;//白天天气
    char *cond_txt_n;//晚间天气
    char *wind_deg;//风向角
    char *wind_dir;//风向
    char *wind_sc;//风力
    char *wind_spd;//风速，公里/小时
    char *hum;//相对湿度
    char *pcpn;//降水量
    char *pop;//降水概率
    char *pres;//大气压强
    char *uv_index;//紫外线强度指数
    char *vis;//能见度，单位：公里
} DailyForecast;


void processDailyForecast(cJSON *dailyForecast);

#endif //SWEATHER_DAILYFORECAST_H
