//
// Created by 冉高飞 on 2018/7/27.
//
#include <strcut_info.h>
#include "lifeStyle.h"
#include "printerUtil.h"

void printLifeStyle(int i) {

    fprintf(stdout, "%s%s %s%s", PURPLE, "➤", context.lifestyleForecast[i].txt, NONE);
}


void processLifeStyle(cJSON *lifeStyle) {
    int length = cJSON_GetArraySize(lifeStyle);
    cJSON *item;
    for (int i = 0; i < length; ++i) {
        item = cJSON_GetArrayItem(lifeStyle, i);
        context.lifestyleForecast[i].brf = cJSON_GetObjectItem(item, "brf")->valuestring;
        context.lifestyleForecast[i].txt = cJSON_GetObjectItem(item, "txt")->valuestring;
        context.lifestyleForecast[i].type = cJSON_GetObjectItem(item, "type")->valuestring;
    }

    MOVEUP(6)
    for (int i = 0; i < 3; i++) {
        MOVELEFT(200)
        MOVERIGHT(45)
        printLifeStyle(i);
        MOVEDOWN(2)
    }
    MOVEUP(1)
    MOVELEFT(200)
}