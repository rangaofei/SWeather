#include <stdio.h>
#include <curl/curl.h>
#include <memory.h>
#include <stdlib.h>
#include "SimpleWeatherConfigure.h"
#include "GetWeather/getweather.h"
#include "Location/location.h"
