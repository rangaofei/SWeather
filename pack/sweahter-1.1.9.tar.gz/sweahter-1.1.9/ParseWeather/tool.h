#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/*************************************************************************
 * 打印分割线
 * @param length
 ************************************************************************/
void print_line(int length);

void print_space(int length);

//void print_center_cn(int length, char *content);
//
//void print_center_en(int length, char *content);

void print_center_mix(int length, char *content);

int regex_cn(char *buf);