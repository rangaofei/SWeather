#include <CJson/cJSON.h>

void print_weather(char *format_string, cJSON* obj, char *key);

void print_weather_two(char *format_string, cJSON* obj, char *key_one, char *key_two);