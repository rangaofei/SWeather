#ifndef defaultconfig_h
#define defaultconfig_h

#include<CJson/cJSON.h>

typedef struct{
    char *add_num;
    int show_version;
    int show_address;
    int show_forecast;
    int show_now;
    int show_hourly;
    int show_lifestyle;
    int show_time;
    int show_air;
};


#endif defaultconfig_h