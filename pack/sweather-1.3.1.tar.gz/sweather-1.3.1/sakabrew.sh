#!/usr/bin/env bash

function findBuild(){
    if [ ! -d "./build" ];then
        mkdir ./build
    else
        echo "build文件夹已经存在"
    fi
}

function cmakeOutBuild(){
    cd ./build
    echo "进入build文件夹，即将清除文件缓存"
    rm -rf ./*
    echo "build文件夹缓存清理完毕，即将执行外部构建"
    cmake ..
    echo "外部构建执行完成"
}
function cmakePackage(){
    cpack --config CPackSourceConfig.cmake
}
function readLogFile(){
    if [ -e "logfile" ];then
        tmp_path=`echo $(pwd) | sed -n "s#/#\\\\\/#gp"`
        echo "$tmp_path"
        package_name=`sed -n '$p' logfile |sed -n "s/.*CPack:.*\($tmp_path.*tar\.gz\).*generated./\1/gp"`
        package_version=`echo "${package_name}" | sed -n s/pack\/\(.*\)\.tar.gz/gp`
        echo "name:${package_name}\n version:${package_version}\n"
    else
        echo "file not found"
    fi
}

function commitToGitHub(){
    if [ ! -n "$package_name" ];then
        echo "不能提交"
    else
        git add ${package_name}
        git commit -m "new version"
        git push
    fi
}

function commitToBrew(){
    if [ ! -n "$package_name" ];then
        echo "不能提交到brew"
    else
        fileSHA256=`openssl dgst -sha256 ${package_name}|sed -n "s/.*= \(.*\)/\1/gp"`
        echo "$fileSHA256"
        cd $(brew --repo rangaofei/saka);cd Formula

    fi

}
findBuild
cmakeOutBuild

if [ ! -e "CPackSourceConfig.cmake" ];then
    echo "未找到打包文件，请重新执行此脚本"
else
    echo "已生成打包文件，即将开始打包"
    name=`cmakePackage`
    echo "------------------------------"
    echo "$name"| tee -a ../logfile
fi
cd ..
readLogFile
commitToGitHub


